<?php
session_start();
ob_start();
error_reporting(0); // jeraldabishek4u@gmail.com;
$success = $_SESSION['log_success'];
$uid = $_SESSION['userid'];
$usern = $_SESSION['username'];
