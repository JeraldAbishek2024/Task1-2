<div class="d-flex justify-content-between align-items-center">
    <div class="d-flex flex-row align-items-center p-2">
        <div>
            <h4 class='m-0'><?php echo $app_name ?></h4>
        </div>
    </div>
    <div class="d-flex flex-row align-items-center p-2">
        <b>
            <h6 class="fs-5 m-0">Welcome <?php echo $usern ?>&#128144;</h6>
        </b>
        &emsp;
        <div class="app-logout"><a href="logout.php" class="btn btn-danger" title="Logout"><span class="mdi mdi-logout"></span> Logout</a></div>
    </div>
</div>