<?php if ($_SESSION['upd_msg'] != "") { ?>
    <div class="alert success" id='success'>
        <span class="closebtn">&times;</span>
        <strong></strong><?php echo htmlentities($_SESSION['upd_msg']); ?>.
    </div>
    <?php echo htmlentities($_SESSION['upd_msg'] = ""); ?>
<?php } ?>
<?php if ($_SESSION['updf_msg'] != "") { ?>
    <div class="alert danger" id='danger'>
        <span class="closebtn">&times;</span>
        <strong></strong><?php echo htmlentities($_SESSION['updf_msg']); ?>.
    </div>
    <?php echo htmlentities($_SESSION['updf_msg'] = ""); ?>
<?php } ?>
<script>
    var close = document.getElementsByClassName("closebtn");
    var i;
    for (i = 0; i < close.length; i++) {
        close[i].onclick = function() {
            var div = this.parentElement;
            div.style.opacity = "0";
            setTimeout(function() {
                div.style.display = "none";
            }, 600);
        }
    }
    setTimeout(function() {
        su = document.getElementById("success");
        if (su == null) {
            document.getElementById("danger").style.opacity = 0;
        } else {
            document.getElementById("success").style.opacity = 0;
        }
    }, 2000);
</script>
<style>
    .alert {
        opacity: 1;
        transition: opacity 0.5s ease;
    }
</style>