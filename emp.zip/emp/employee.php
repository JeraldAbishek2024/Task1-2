<?php
include("includes/preload.php");
if ($success == NULL) {
    header('location:index.php');
} else {
    include('includes/config.php');
    include('includes/constant.php');
    include('includes/function.php');
    //
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <title><?php echo $app_name ?></title>
        <link rel="icon" href="<?php echo $app_logo ?>" type="image/x-icon">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="assets/css/boxicons.min.css">
        <script src="bootstrap-5.2.3/js/bootstrap.min.js"></script>
        <link href="bootstrap-5.2.3/css/bootstrap.min.css" rel="stylesheet">
        <script src="bootstrap-5.2.3/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/jquery.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/@mdi/font@7.1.96/css/materialdesignicons.min.css" rel="stylesheet" />
        <link rel="shortcut icon" href="assets/img/kxp_fav.png" type="image/x-icon" />
        <link rel="stylesheet" href="assets/css/style.css" />
        <link href="DataTables/datatables.min.css" rel="stylesheet" />
        <script src="DataTables/datatables.min.js"></script>

        <style>
            label {
                display: flex;
                width: 120px;
            }

            label p {
                margin: 0px;
            }

            .form-field {
                display: flex;
                margin-bottom: 10px;
            }

            input[type='submit'] {
                float: inline-end;

            }
        </style>
    </head>

    <body>
        <div class="se-pre-con"></div>
        <?php
        $qry = "SELECT * FROM `employee` order by emp_id desc";
        $q = $pdo->prepare($qry);
        $q->execute();
        $q = $q->fetchAll();
        $qry2 = "SELECT * FROM `employee` order by emp_id desc";
        $q2 = $pdo->prepare($qry2);
        $q2->execute();
        $q2 = $q2->fetchAll();
        ?>
        <section class="home">
            <!-- modal -->
            <?php foreach ($q2 as $q2) :
                $data = $q2;
            ?>
                <div class="modal fade" id="editModal<?php echo $data['emp_id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Employee</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="services/employee_services.php" method="post" enctype="multipart/form-data">
                                    <input name="eid" type="hidden" value="<?php echo $data['emp_id']; ?>">
                                    <div class="form-flex">
                                        <div class="form-field">
                                            <label>Name :<p class="text-danger">*</p></label>
                                            <input type="text" class="form-control" name="ename" value="<?php echo $data['emp_name']; ?>" required>
                                        </div>
                                        <div class="form-field">
                                            <label>Departmant :<p class="text-danger">*</p></label>
                                            <select class="form-select" name="edept">
                                                <?php
                                                $opcrt = $data['emp_dept'];
                                                $qry4 = "SELECT * FROM `option` WHERE op_type='dept'";
                                                $q4 = $pdo->prepare($qry4);
                                                $q4->execute();
                                                $q4 = $q4->fetchAll();
                                                foreach ($q4 as $q4) :
                                                    $op = $q4['op_name'];
                                                    if ($op == $opcrt) {
                                                        $choose = "selected";
                                                    } else {
                                                        $choose = "";
                                                    }
                                                ?>
                                                    <option <?php echo $choose; ?>><?php echo $op; ?></option>
                                                <?php
                                                endforeach;
                                                ?>
                                            </select>
                                        </div>
                                        <div class="form-field">
                                            <label class="form-label">Designation :<p class="text-danger">*</p></label>
                                            <select class="form-select" name="edesg">
                                                <?php
                                                $opcrt = $data['emp_desg'];
                                                $qry4 = "SELECT * FROM `option` WHERE op_type='desg'";
                                                $q4 = $pdo->prepare($qry4);
                                                $q4->execute();
                                                $q4 = $q4->fetchAll();
                                                foreach ($q4 as $q4) :
                                                    $op = $q4['op_name'];
                                                    if ($op == $opcrt) {
                                                        $choose = "selected";
                                                    } else {
                                                        $choose = "";
                                                    }
                                                ?>
                                                    <option <?php echo $choose; ?>><?php echo $op; ?></option>
                                                <?php
                                                endforeach;
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-flex">
                                        <div class="form-field">
                                            <label class="form-label">E-mail :<p class="text-danger">*</p></label>
                                            <input type="email" name="email" class="form-control" value="<?php echo $data['emp_mail']; ?>" required>
                                        </div>
                                        <div class="form-field">
                                            <label class="form-label">Phone (+91) :<p class="text-danger">*</p></label>
                                            <input class="form-control" type="number" name="ephone" value="<?php echo $data['emp_phone']; ?>" required>
                                        </div>
                                    </div>
                                    <input name="update" class="btn btn-outline-primary" type="submit" value="Update" id="update">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            <!--  -->
            <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Add Employee</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="services/employee_services.php" method="post">
                                <div class="form-flex">
                                    <div class="form-field">
                                        <label>Name :<p class="text-danger">*</p></label>
                                        <input type="text" class="form-control" name="ename" required>
                                    </div>
                                    <div class="form-field">
                                        <label>Departmant :<p class="text-danger">*</p></label>
                                        <select class="form-select" name="edept">
                                            <?php
                                            $qry4 = "SELECT * FROM `option` WHERE op_type='dept'";
                                            $q4 = $pdo->prepare($qry4);
                                            $q4->execute();
                                            $q4 = $q4->fetchAll();
                                            foreach ($q4 as $q4) :
                                                $op = $q4['op_name'];
                                            ?>
                                                <option><?php echo $op; ?></option>
                                            <?php
                                            endforeach;
                                            ?>
                                        </select>
                                    </div>
                                    <div class=" form-field">
                                        <label class="form-label">Designation :<p class="text-danger">*</p></label>
                                        <select class="form-select" name="edesg">
                                            <?php
                                            $qry4 = "SELECT * FROM `option` WHERE op_type='desg'";
                                            $q4 = $pdo->prepare($qry4);
                                            $q4->execute();
                                            $q4 = $q4->fetchAll();
                                            foreach ($q4 as $q4) :
                                                $op = $q4['op_name'];
                                            ?>
                                                <option><?php echo $op; ?></option>
                                            <?php
                                            endforeach;
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-flex">
                                    <div class="form-field">
                                        <label class="form-label">E-mail :<p class="text-danger">*</p></label>
                                        <input type="email" class="form-control" name="email" required>
                                    </div>
                                    <div class="form-field">
                                        <label class="form-label">Phone (+91) :<p class="text-danger">*</p></label>
                                        <input type="number" class="form-control" name="ephone" required>
                                    </div>
                                </div>
                                <input name="add" class="btn btn-outline-primary" type="submit" value="Submit" id="update">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <!--  -->
            <section class="home">
                <?php
                include('includes/alert.php');
                include "includes/header.php";
                ?>
                <hr class="m-0">
                <div class="main-section p-2">
                    <div class="m-4">
                        <div class="d-flex flex-row justify-content-between">
                            <div class="head-title mb-3">
                                <h4>Employee Details</h4>
                            </div>
                            <div class="head-opt">
                                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal" title="Add Employee">Add</button>
                            </div>
                        </div>
                        <div class="table-responsive py-3">
                            <table class="table table-sm table-bordered table-striped table-hover py-2" id="myTable">
                                <thead>
                                    <tr>
                                        <th scope="col">S.No</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Department</th>
                                        <th scope="col">Designation</th>
                                        <th scope="col">E-mail</th>
                                        <th scope="col">Phone</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 0;
                                    foreach ($q as $q) :
                                        $i++;
                                    ?>
                                        <tr>
                                            <td scope="row"><?php echo $i ?></td>
                                            <td><?php echo ucfirst($q['emp_name']); ?></td>
                                            <td><?php echo $q['emp_dept'] ?></td>
                                            <td><?php echo $q['emp_desg'] ?></td>
                                            <td><?php echo $q['emp_mail'] ?></td>
                                            <td><?php echo $q['emp_phone'] ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $q['emp_id'] ?>" title="Edit Employee">Edit</button>&emsp;
                                                <a href="services/employee_services.php?del_id=<?php echo $q['emp_id'] ?>" class="btn btn-sm btn-danger" onclick="confirm_delete()" title="Delete Employee">Delete</a>
                                            </td>
                                        </tr>
                                    <?php
                                    endforeach;
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
    </body>
    <script>
        new DataTable('#myTable');

        function confirm_delete() {
            var r = confirm("Are you sure you want to delete?");
            if (r == true) {} else {
                event.preventDefault();
            }
        }
    </script>
    <?php
    include('includes/footer.php');
    ?>
    </body>

    </html>
<?php } ?>