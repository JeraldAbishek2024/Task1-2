<?php
include('../includes/preload.php');
if ($success == NULL) {
    header('location:../index.php');
} else {
    include('../includes/config.php');
    include('../includes/constant.php');
    $content = 'Employee';
    $redirect = '../employee.php';
    // DELETE
    $delid = $_GET['del_id'];
    if ($delid) {
        $id = $delid;
        $sql = "DELETE FROM emp.employee where emp_id=$delid";
        if ($conn->query($sql) === TRUE) {
            $_SESSION['upd_msg'] = "$content Deleted Successfully";
            header("location:$redirect");
        } else {
            $_SESSION['updf_msg'] = "$content Deleted Failed";
            header("location:$redirect");
        }
    }
    // ADD
    if (isset($_POST['add'])) {
        $en = $_POST['ename'];
        $edp = $_POST['edept'];
        $eds = $_POST['edesg'];
        $em = $_POST['email'];
        $ep = $_POST['ephone'];
        //
        $sql = "INSERT INTO emp.employee (emp_name,emp_dept,emp_desg,emp_mail,emp_phone) VALUES ('$en','$edp','$eds','$em',$ep);";
        echo $sql;
        if ($conn->query($sql) === TRUE) {
            $_SESSION['upd_msg'] = "$content Added Successfully";
            header("location:$redirect");
        } else {
            $_SESSION['updf_msg'] = "$content added Failed";
            header("location:$redirect");
        }
    }
    // UPDATE
    if (isset($_POST['update'])) {
        $eid = $_POST['eid'];
        $en = $_POST['ename'];
        $edp = $_POST['edept'];
        $eds = $_POST['edesg'];
        $em = $_POST['email'];
        $ep = $_POST['ephone'];
        $sql = "UPDATE emp.employee SET emp_name='$en' , emp_dept='$edp' , emp_desg='$eds' , emp_mail='$em' , emp_phone=$ep where emp_id=$eid";
        echo $sql;
        if ($conn->query($sql) === TRUE) {
            $_SESSION['upd_msg'] = "$content Updated Successfully";
            header("location:$redirect");
        } else {
            $_SESSION['updf_msg'] = "$content Updated Failed";
            header("location:$redirect");
        }
    }
}
