<?php
include('../includes/config.php');
session_start();
if (isset($_POST['register'])) {
    $un = $_POST['username'];
    $pwd = $_POST['pswd'];
    $cpwd = $_POST['cpswd'];
    $mail = $_POST['email'];
    $ph = $_POST['phone'];
    if ($pwd != $cpwd) {
        $_SESSION['updf_msg'] = "User added Failed Due to Password mismatch";
        header("location:../index.php");
    }
    try {
        $sql = "INSERT INTO emp.login (login_name,login_mail,login_phone,login_pwd) VALUES ('$un','$mail',$ph,'$pwd')";
        echo $sql;
        if ($conn->query($sql) === TRUE) {
            $_SESSION['upd_msg'] = "User added Successfully";
            header("location:../index.php");
        } else {
            $_SESSION['updf_msg'] = "User added Failed";
            header("location:../index.php");
        }
    } catch (Exception $e) {
        $_SESSION['updf_msg'] = "User added Failed Due to Username Already Exist";
        header("location:../index.php");
    }
}
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['pswd'];

    $sql = "SELECT * FROM emp.login WHERE login_name='$username' AND login_pwd='$password'";
    $result = mysqli_query($conn, $sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $userid = $row['login_id'];
        }
    }
    $count = mysqli_num_rows($result);
    if ($count == 1) {
        $_SESSION['log_success'] = '1';
        $_SESSION['userid'] = $userid;
        $_SESSION['username'] = $username;
        $_SESSION['upd_msg'] = "Logged In Successfully";
        header('location:../employee.php');
    } else {
        $_SESSION['updf_msg'] = "Invalid Details";
        header('location:../index.php');
    }
}
