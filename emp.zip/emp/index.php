<!DOCTYPE html>
<html lang="en">
<?php
include "includes/preload.php";
include "includes/constant.php";
?>

<head>
    <title><?php echo $app_name ?></title>
    <link rel="icon" href="<?php echo $app_logo ?>" type="image/x-icon">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="assets/css/boxicons.min.css">
    <script src="bootstrap-5.2.3/js/bootstrap.min.js"></script>
    <link href="bootstrap-5.2.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap-5.2.3/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/@mdi/font@7.1.96/css/materialdesignicons.min.css" rel="stylesheet" />
    <link rel="shortcut icon" href="assets/img/kxp_fav.png" type="image/x-icon" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link href="DataTables/datatables.min.css" rel="stylesheet" />
    <script src="DataTables/datatables.min.js"></script>
    <style>
        form {
            min-width: 350px;
            border-radius: 5px;
            border: 3px solid black;
        }

        form h3 {
            text-align: center;
        }

        .submit {
            background-color: var(--third);
            color: var(--light);
        }

        label b {
            display: flex;
        }

        label b p {
            margin: 0px;
        }
    </style>
</head>

<body>
    <?php include('includes/alert.php'); ?>
    <div class="container d-flex flex-row flex-wrap justify-content-around align-items-center">
        <form action="services/auth_services.php" method="post" class='m-2 p-2'>
            <h3>Register</h3>
            <div class="sub-container">
                <label class="form-label" for="uname"><b>Username &ensp;<p class="text-danger"> *</p></b></label>
                <input type="text" placeholder="Enter Username" name="username" class="form-control my-2" required>
                <label class="form-label" for="uname"><b>Email &ensp; <p class="text-danger"> *</p></b></label>
                <input type="email" placeholder="Enter Email" name="email" class="form-control my-2" required>
                <label class="form-label" for="uname"><b>Phone &ensp;<p class="text-danger"> *</p></b></label>
                <input type="number" placeholder="Enter Phone Number" name="phone" class="form-control my-2" required>
                <label class="form-label" for="psw"><b>Password &ensp; <p class="text-danger"> *</p></b></label>
                <input type="password" placeholder="Enter Password" name="pswd" class="form-control my-2" required>
                <label class="form-label" for="psw"><b>Confirm Password&ensp; <p class="text-danger"> *</p></b></label>
                <input type="password" placeholder="Enter Confirm Password" name="cpswd" class="form-control my-2" required>
                <input class="form-control submit" type="submit" name="register" value="Register">
            </div>
        </form>
        <form action="services/auth_services.php" method="post" class='m-2 p-2'>
            <h3>Login</h3>
            <div class="sub-container">
                <label class="form-label" for="uname"><b>Username &ensp; <p class="text-danger"> *</p></b></label>
                <input type="text" placeholder="Enter Username" name="username" class="form-control my-2" required>
                <label class="form-label" for="psw"><b>Password &ensp; <p class="text-danger"> *</p></b></label>
                <input type="password" placeholder="Enter Password" name="pswd" class="form-control my-2" required>
                <input class="form-control submit" type="submit" name="login" value="Login">
            </div>
        </form>
    </div>
</body>

</html>
<?php
include('includes/footer.php');
?>