function checkSpecialCharacters(inputField) {
    const inputElements = document.querySelectorAll(".username");
    const submitButtons = document.querySelectorAll(".btn-submit");
    inputElements.forEach(function (inputElement, index) {
        inputElement.addEventListener("input", function () {
            // Define a regular expression pattern to match special characters
            var pattern = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~\s]/;

            // Get the value entered in the input field
            var inputValue = inputField.value;

            // Check if the value contains any special characters
            if (pattern.test(inputValue)) {
                submitButtons[index].setAttribute("disabled", "disabled");
                submitButtons[index].style.opacity = 0.5;
                inputElement.style.color = "red";
            } else {
                submitButtons[index].removeAttribute("disabled");
                submitButtons[index].style.opacity = 1;
                inputElement.style.color = "green";
            }
        });
    });
}

function checkadmin(input) {
    var ipval = input.value;
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var response = JSON.parse(xhr.responseText);
            console.log(response);
            if (response) {
                document.getElementById('empid').style.color = "red";
                input.style.color = "red";
                document.getElementById('add').style.opacity = 0.5;
                document.getElementById('add').setAttribute("disabled", "disabled");
            } else {
                document.getElementById('empid').style.color = "green";
                input.style.color = "green";
                document.getElementById('add').style.opacity = 1;
                document.getElementById('add').removeAttribute("disabled");
            }
        }
    };
    xhr.open('GET', 'ajax/fetch_admin.php?ipval=' + ipval, true);
    xhr.send();
}

function checkempid(input) {
    var ipval = input.value;
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var response = JSON.parse(xhr.responseText);
            console.log(response);
            if (response) {
                document.getElementById('empid').style.color = "red";
                input.style.color = "red";
                document.getElementById('add').style.opacity = 0.5;
                document.getElementById('update').style.opacity = 0.5;
                document.getElementById('add').setAttribute("disabled", "disabled");
                document.getElementById('update').setAttribute("disabled", "disabled");
            } else {
                document.getElementById('empid').style.color = "green";
                input.style.color = "green";
                document.getElementById('add').style.opacity = 1;
                document.getElementById('update').style.opacity = 1;
                document.getElementById('add').removeAttribute("disabled");
                document.getElementById('update').removeAttribute("disabled");
            }
        }
    };
    xhr.open('GET', 'ajax/fetch_empid.php?ipval=' + ipval, true);
    xhr.send();
}

function validateEmail(emailInput) {
    // Regular expression to validate an email address
    const inputElements = document.querySelectorAll(".emailInput");
    const submitButtons = document.querySelectorAll(".btn-submit");
    inputElements.forEach(function (inputElement, index) {
        inputElement.addEventListener("input", function () {
            const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
            var email = emailInput.value;

            if (email.match(emailRegex)) {
                submitButtons[index].removeAttribute("disabled");
                submitButtons[index].style.opacity = 1;
                inputElement.style.color = "green";
            } else {
                submitButtons[index].setAttribute("disabled", "disabled");
                submitButtons[index].style.opacity = 0.5;
                inputElement.style.color = "red";
            }
        });
    });
}

// 
function validatePhone(phone) {
    const inputElements = document.querySelectorAll(".phoneInput");
    const submitButtons = document.querySelectorAll(".btn-submit");
    inputElements.forEach(function (inputElement, index) {
        inputElement.addEventListener("input", function () {
            const inputValue = this.value;
            const isValid = /^\d{10}$/.test(inputValue);
            if (isValid) {
                submitButtons[index].removeAttribute("disabled");
                submitButtons[index].style.opacity = 1;
                inputElement.style.color = "green";
            } else {
                submitButtons[index].setAttribute("disabled", "disabled");
                submitButtons[index].style.opacity = 0.5;
                inputElement.style.color = "red";
            }
        });
    });
}
