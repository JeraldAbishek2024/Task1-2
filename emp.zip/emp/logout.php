<?php
session_start();
include('includes/config.php');
$_SESSION = array();
// unset($_SESSION['login']);
// unset($_SESSION['userid']);
session_destroy();
header("location:index.php");
